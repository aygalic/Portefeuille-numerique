$(document).ready(function(){
        //$('.collapse').collapse();
        //var a =$('body').offset().top + $('.projets').offset().top;
        //$('.img-porteF').css("top", a.toString()+"px");


});
