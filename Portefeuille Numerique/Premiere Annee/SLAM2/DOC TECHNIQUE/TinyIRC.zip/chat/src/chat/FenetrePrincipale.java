package chat;

import chat.Chat;
//import javafx
import javafx.animation.FadeTransition;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.ScaleTransition;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.Tab;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.TextAlignment;
import javafx.scene.transform.Rotate;
import javafx.scene.transform.Translate;
import javafx.stage.FileChooser;
import javafx.stage.Popup;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.WindowEvent;
import javafx.util.Duration;

//import java net ect.
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 *  FenetrePrincipale est la classe qui contient tout les �l�ment graphique, ainsi que leurs interactions
 *  avec les autres classes et le serveur.
 *  Tout les �lement JavaFX sont cr��s i�i
 *  
 * @author Aygalic
 *
 */


public class FenetrePrincipale extends Application {
	/**
	 * Strings correspondant au informations utiles a la conexion
	 * nick et channel permettent aussi de v�rifier la cible des messages re�us 
	 */
	public String serveur, nick, channel, login;
	/**
	 * Le port sert lui aussi a la connexion.
	 */
	int port;
	/**
	 * Objet Chat propre a la connexion, qui contien toutes les methodes utiles pour se connecter, 
	 * lire et �crire au serveur.
	 * 
	 * @see Chat
	 */
	Chat c;
	/**
	 * boolean de test qui permet de savoir si la connexion au serveur a bien �t�e effectu�e.
	 * Elle est invalid� lors ce qu'on se d�connecte.
	 * Elle permet de gener le runnable qui actualise de chat en permanance.
	 */
	boolean co = false;
	/**
	 * items correspond au pseudo des utilisateurs connect�s en temps r�el sur le channel.
	 */
	ObservableList<String> items;

	
	/**
	 * Methode qui execute le programme.
	 * 
	 * @param args permet de faire passer des parametre via l'invite de commande par exemple.
	 * Ici ces parametres ne sont pas exploit�s
	 */
	public static void main(String[] args) {
		launch(args);
	}

	/**
	 * methode start dans laquelle est instanci� tout les �l�ments de la fenetre
	 * 
	 * @param primaryStage
	 * @throws IOException, UnknownHostExeption pour plus de tol�rance au erreurs d'entr�e sortie.
	 * concerne surtout la communication avec le serveur et les fichier
	 */
	@Override
	public void start(final Stage primaryStage) throws UnknownHostException, IOException {

		// **************************cr�ation des �l�ments*******************************
		// -------------------�l�ments de la fenetre de connexion-----------------------
		final GridPane gPane = new GridPane();
		final Label lblNick = new Label("Nick:");
		final Label lblServeur = new Label("Serveur:");
		final Label lblPort = new Label("Port:");
		final Label lblChannel = new Label("Channel:");
		final Label lblLogin = new Label("Login :");
		final TextField txtNick = new TextField("");
		final TextField txtServeur = new TextField("");
		final TextField txtPort = new TextField("");
		final TextField txtChannel = new TextField("");
		final TextField txtLogin = new TextField("");
		final CheckBox checkBoxRemindMe = new CheckBox();
		final Label labelRemindMe = new Label("Se souvenir de moi : ");
		final Button btnConnexion = new Button("Connection");
		final Stage stageConnection = new Stage();
		final Scene sConnection = new Scene(gPane, 450, 250);
		
		final Popup popup = new Popup();
		final Rectangle rectanglePopup = new Rectangle(4.5, 10, Color.web("#ffb347"));
		final Label lblPopup = new Label("Veuillez completer tout les champs\nVeuillez ne pas mettre d'espaces");

		// -------------------------element de l'�cran de chargement--------------------
		final StackPane sPane = new StackPane();
		final ProgressIndicator progressIndicator = new ProgressIndicator(-1);
		final Stage stageLoading = new Stage();
		final Scene sLoading = new Scene(sPane, 400, 200);

		// ---------------------------element de la fenetre principale---------------------
		final SimpleDateFormat formater = new SimpleDateFormat("hh:mm");
		final Image imageSend = new Image(FenetrePrincipale.class.getResourceAsStream("envoyer.png"));
		Image imageOption = new Image(FenetrePrincipale.class.getResourceAsStream("option.png"));
		final ImageView btnSend = new ImageView(imageSend);
		final ImageView btnOption = new ImageView(imageOption);

		final AnchorPane root = new AnchorPane();

		final TextField txtSend = new TextField();
		final TextArea logTextArea = new TextArea();
		final TextArea chatArea = new TextArea();

		final CustomTabPane tabpane = new CustomTabPane();
		final Tab tab1 = new Tab("Messages");
		final Tab tab2 = new Tab("Log");
		final Scene scene = new Scene(root, 1024, 768);

		// priv messages
		final ListView<String> listUtilisateurs = new ListView<String>();
		final ContextMenu contextMenu = new ContextMenu();

		// menu
		final MenuItem exitItem = new MenuItem("Quitter");
		final MenuItem reconectItem = new MenuItem("Se reconnecter");
		final MenuItem logItem = new MenuItem("Ouvrir les logs");
		final MenuItem saveItem = new MenuItem("Enregistrer les logs");

		// ******************************CSS***********************************
		txtSend.setId("txtSend");
		tabpane.setId("tabpane");
		btnSend.setId("btnSend");
		btnOption.setId("btnOption");
		chatArea.setId("chatArea");

		// ***********************positionement des �l�ments********************
		// -----------------fenetre Conexion----------------------------------
		gPane.setAlignment(Pos.CENTER);
		gPane.setHgap(5.0);
		gPane.setVgap(5.0);
		gPane.add(lblNick, 0, 0);
		gPane.add(txtNick, 1, 0);
		gPane.add(lblLogin, 0, 1);
		gPane.add(txtLogin, 1, 1);
		gPane.add(lblServeur, 0, 2);
		gPane.add(txtServeur, 1, 2);
		gPane.add(lblPort, 0, 3);
		gPane.add(txtPort, 1, 3);
		gPane.add(lblChannel, 0, 4);
		gPane.add(txtChannel, 1, 4);
		gPane.add(labelRemindMe, 0, 5);
		gPane.add(checkBoxRemindMe, 1, 5);
		gPane.add(btnConnexion, 1, 6);
		stageConnection.setScene(sConnection);
		txtChannel.setPromptText("#channel");
		txtLogin.setPromptText("Votre nom d'utilisateur");
		txtNick.setPromptText("Votre Pseudo");
		txtPort.setPromptText("6667");
		txtServeur.setPromptText("votreserveur.exemple");

		lblPopup.setStyle("-fx-font-size : 15pt;-fx-font-weight : bold;");
		lblPopup.setTranslateX(-220);
		lblPopup.setTranslateY(-25);
		lblPopup.setTextAlignment(TextAlignment.LEFT);
		lblPopup.setTextFill(Color.web("#4793ff"));
		lblPopup.setTextFill(Color.DARKSLATEGREY);
		lblPopup.setOpacity(0);

		// ----------------------------Ecran de chargement
		// ------------------------
		sPane.getChildren().add(progressIndicator);
		stageLoading.initStyle(StageStyle.TRANSPARENT);
		sPane.setBackground(Background.EMPTY);
		sLoading.setFill(Color.TRANSPARENT);
		stageLoading.setScene(sLoading);
		popup.setAutoHide(true);
		popup.getContent().addAll(rectanglePopup, lblPopup);

		// ---------------------------fenetre
		// principale---------------------------
		primaryStage.setTitle("TinyIRC");
		// propri�t�s des textArea
		txtSend.setPromptText("Entrez votre texte....");
		txtSend.setMinHeight(80.0);
		txtSend.setPadding(new Insets(0, 90, 0, 10));
		btnOption.setPickOnBounds(true);// rendre les parties transparentes de l'image clicables

		logTextArea.setEditable(false);
		chatArea.setWrapText(true);
		chatArea.setEditable(false);
		// tabpane pour l'affichage des string
		tab1.setClosable(false);
		tab1.setContent(chatArea);
		tab2.setContent(logTextArea);
		tabpane.getTabs().setAll(tab1);
		listUtilisateurs.setPrefWidth(200);
		contextMenu.getItems().setAll(exitItem, reconectItem, new SeparatorMenuItem(), logItem, saveItem);
		listUtilisateurs.setContextMenu(contextMenu);
		// menu

		// -EN-POSITION-!-
		// pr�paration de AnchorPane
		// positionnement de la zone de saisie
		root.getChildren().add(txtSend);
		AnchorPane.setBottomAnchor(txtSend, 0.0);
		AnchorPane.setLeftAnchor(txtSend, 0.0);
		AnchorPane.setRightAnchor(txtSend, 0.0);

		// positionement de la liste des utilisateurs
		root.getChildren().add(listUtilisateurs);
		AnchorPane.setTopAnchor(listUtilisateurs, 0.0);
		AnchorPane.setLeftAnchor(listUtilisateurs, 0.0);
		AnchorPane.setBottomAnchor(listUtilisateurs, 80.0);

		// positionement du chatArea
		root.getChildren().add(tabpane);
		AnchorPane.setBottomAnchor(tabpane, 80.0);
		AnchorPane.setTopAnchor(tabpane, 0.0);
		AnchorPane.setRightAnchor(tabpane, 0.0);
		AnchorPane.setLeftAnchor(tabpane, 200.0);
		primaryStage.setScene(scene);
		// positionement du bouton Option
		root.getChildren().add(btnOption);
		AnchorPane.setTopAnchor(btnOption, 60.0);
		AnchorPane.setRightAnchor(btnOption, 30.0);

		// positionement du boutton Envoyer
		root.getChildren().add(btnSend);
		AnchorPane.setRightAnchor(btnSend, 8.0);
		AnchorPane.setBottomAnchor(btnSend, 8.0);

		// -----------------------------------------------------------------------------
		// ------------------------FIN DE LA MISE EN PAGE-------------------------------
		// -----------------------------------------------------------------------------

		// initialisation du programme

		File checkFile = new File("config.txt");
		boolean exists = checkFile.exists();
		if (exists) {
			if (checkFile != null) {
				if (readFile(checkFile).split(" ")[0].equals("true")) {
					checkBoxRemindMe.setSelected(true);

					txtChannel.setText(readFile(checkFile).split(" ")[1]);
					txtLogin.setText(readFile(checkFile).split(" ")[2]);
					txtNick.setText(readFile(checkFile).split(" ")[3]);
					txtPort.setText(readFile(checkFile).split(" ")[4]);
					txtServeur.setText(readFile(checkFile).split(" ")[5]);

				}
				;
			}
		}

		stageConnection.show();
		stageConnection.setResizable(false);
		scene.getStylesheets().add(FenetrePrincipale.class.getResource("style.css").toExternalForm());


		// -----------------------Gestion des �venements---------------------------

		// sauvegarder les logs dans un fichier
		saveItem.setOnAction((ActionEvent event) -> {
			FileChooser fileChooser = new FileChooser();

			// Set extension filter
			FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("TXT files (*.txt)", "*.txt");
			fileChooser.getExtensionFilters().add(extFilter);

			// Show save file dialog
			File file = fileChooser.showSaveDialog(primaryStage);

			if (file != null) {
				SaveFile(logTextArea.getText(), file);
			}
		});

		// ouvrir un onglet de chat priv�
		listUtilisateurs.setOnMouseClicked(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent mouseEvent) {
				if (mouseEvent.getButton().equals(MouseButton.PRIMARY)) {
					if (mouseEvent.getClickCount() == 2) {
						System.out.println("Double clicked");
						CustomTab tabPrivate = new CustomTab(listUtilisateurs.getSelectionModel().getSelectedItem());
						tabpane.addCTab(tabPrivate);
					}
				}
			}
		});

		// evenement menu
		btnOption.setOnMouseClicked(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent event) {
				contextMenu.show(btnOption, event.getScreenX(), event.getScreenY());
			}
		});

		logItem.setOnAction(actionEvent -> tabpane.getTabs().add(tab2));
		exitItem.setOnAction(
				actionEvent -> primaryStage.fireEvent(new WindowEvent(primaryStage, WindowEvent.WINDOW_CLOSE_REQUEST)));
		reconectItem.setOnAction(actionEvent -> {
			co = false;
			try {
				c.exit();
			} catch (Exception e) {
				e.printStackTrace();
			}
			primaryStage.hide();
			stageConnection.show();
		});

		tab2.setOnCloseRequest(actionEvent -> {
			tabpane.getTabs().remove(tab2);
		});

		// Envoyer un message avec le bouton
		btnSend.setOnMouseClicked(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if (!txtSend.getText().isEmpty()) {
					if (tabpane.getSelectionModel().getSelectedItem() == tab1
							|| tabpane.getSelectionModel().getSelectedItem() == tab2) {
						if (txtSend.getText() != ("")) {
							txtSend.requestFocus();
							logTextArea.appendText(txtSend.getText() + "\n");
							chatArea.appendText("[" + formater.format(new Date()) + "] : " + nick + " : "
									+ txtSend.getText() + "\n");
							try {
								c.sendMessage(txtSend.getText());
							} catch (IOException e) {
								System.out.println("fail");
								e.printStackTrace();
							}
							txtSend.clear();
						}
					} else if (tabpane.getSelectionModel().getSelectedItem() == tab2) {
						txtSend.requestFocus();
						logTextArea.appendText(txtSend.getText() + "\n");
						try {
							c.getWriter().write(txtSend.getText() + "\r\n");
							c.getWriter().flush();

						} catch (IOException e) {
							e.printStackTrace();
						}
						txtSend.clear();
					} else {
						txtSend.requestFocus();
						String utilisateur = tabpane.getSelectionModel().getSelectedItem().getText().toString();
						System.out.println(utilisateur);
						try {
							c.sendPrivMessage(txtSend.getText(), utilisateur);
						} catch (IOException e) {
							e.printStackTrace();
						}
						tabpane.getCTabByName(utilisateur).getTA().appendText(nick + " : " + txtSend.getText() + "\n");
						txtSend.clear();
					}
				}
			}
		});

		// Envoyer un message avec la touche entr�e
		txtSend.setOnKeyPressed(new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent keyEvent) {
				if (keyEvent.getCode().toString() == "ENTER") {
					if (!txtSend.getText().isEmpty()) {
						if (tabpane.getSelectionModel().getSelectedItem() == tab1) {
							if (txtSend.getText() != ("")) {
								txtSend.requestFocus();
								logTextArea.appendText(txtSend.getText() + "\n");
								chatArea.appendText("[" + formater.format(new Date()) + "] : " + nick + " : "
										+ txtSend.getText() + "\n");
								try {
									c.sendMessage(txtSend.getText());
								} catch (IOException e) {
									System.out.println("fail");
									e.printStackTrace();
								}
								txtSend.clear();
							}
						} else if (tabpane.getSelectionModel().getSelectedItem() == tab2) {
							txtSend.requestFocus();
							logTextArea.appendText(txtSend.getText() + "\n");
							try {
								c.getWriter().write(txtSend.getText() + "\r\n");
								c.getWriter().flush();

							} catch (IOException e) {
								e.printStackTrace();
							}
							txtSend.clear();

						} else {
							txtSend.requestFocus();
							String utilisateur = tabpane.getSelectionModel().getSelectedItem().getText().toString();
							try {
								c.sendPrivMessage(txtSend.getText(), utilisateur);

							} catch (IOException e) {
								e.printStackTrace();
							}
							tabpane.getCTabByName(utilisateur).getTA()
									.appendText(nick + " : " + txtSend.getText() + "\n");
							txtSend.clear();

						}
					}
				}
			}
		});

		// bouton connexion
		btnConnexion.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// operation pour la checkbox "se souvenir de moi"
				// v�rifier la valdit� des informations entr�es
				if (!txtChannel.getText().contains(" ") && !txtLogin.getText().contains(" ")
						&& !txtNick.getText().contains(" ") && !txtPort.getText().contains(" ")
						&& !txtServeur.getText().contains(" ") && !txtChannel.getText().isEmpty()
						&& !txtLogin.getText().isEmpty() && !txtNick.getText().isEmpty() && !txtPort.getText().isEmpty()
						&& !txtServeur.getText().isEmpty()) {

					File file = new File("config.txt");
					String config = checkBoxRemindMe.isSelected() + " " + txtChannel.getText() + " "
							+ txtLogin.getText() + " " + txtNick.getText() + " " + txtPort.getText() + " "
							+ txtServeur.getText() + " " + txtServeur.getText();
					SaveFile(config, file);
					// fin de la sauvegarde des informations "se souvenir de moi"
					// R�cup�re les informations dans les textField
					stageConnection.hide();
					stageLoading.show();

					serveur = txtServeur.getText();
					nick = txtNick.getText();
					port = Integer.parseInt(txtPort.getText());
					channel = txtChannel.getText();
					login = txtLogin.getText();
					while (co == false) {
						try {
							// cr�e la connexion au serveur
							c = Chat.createConnexion(nick, login, channel, serveur, port);
							co = true;
							System.out.println("connect� au serveur");
						} catch (IOException e) {
							System.out.println("Connection erreur");
							e.printStackTrace();
						}
					}

				} else {
					popup.show(stageConnection);
				}

			}
		});
		// ouverture de la fenetre principale a la fin du chargement
		stageLoading.setOnHiding((event) -> primaryStage.show());

		// Pour que l'application s'arrete correctement quand on appui sur la croix
		primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent event) {
				if (co = true) {
					try {
						co = false;
						c.exit();// d�connexion "propre"
					} catch (IOException e) {
						// e.printStackTrace();
					} finally {
						System.exit(0);
					}
				}
			}
		});
		stageConnection.setOnCloseRequest((event) -> System.exit(0));
		// pas de socket ouvert � ce stade

		// lecture de l'entr�e IRC
		Runnable readingRunnable = new Runnable() {
			public void run() {
				if (co) {
					String tampon = " ";
					try {
						tampon = c.read();
						logTextArea.appendText(tampon + "\n");
						System.out.println(tampon);
						if (tampon.split(" ")[1].length() != 3) {//�limination du premier message du serveur
							if (tampon.split(":")[1].contains("PRIVMSG") && tampon.split(" ")[2].contains(channel)) {
								String pseudo = tampon.split(":")[1].split("!")[0];
								String message = tampon.substring(tampon.indexOf(":", tampon.indexOf(":") + 1) + 1);
								chatArea.appendText(
										"[" + formater.format(new Date()) + "] : " + pseudo + " : " + message + "\n");
							} else if (tampon.split(":")[1].contains("PRIVMSG")
									&& tampon.split(" ")[2].contains(nick)) {
								System.out.println("PRIV MESSAGE");
								String from = tampon.split(":")[1].split("!")[0];
								String message = tampon.substring(tampon.indexOf(":", tampon.indexOf(":") + 1) + 1);
								System.out.println(from + " : " + message);
								boolean test = false;
								for (int i = 0; i < tabpane.getTabs().size(); i++) {// parcourir tout les ongets
									if (tabpane.getTabs().get(i).getText().equals(from)) {// v�rifier que l'onglet de discution appropori� existe
										tabpane.getCTabByName(from).getTA().appendText("[" + formater.format(new Date()) + "] : " +from + " : " + message + "\n");
										test = true;// l'onglet �tait deja ouvert, on passe la v�rification suivante
									}
								}
								if (!test) {
									Platform.runLater(new Runnable() {
										@Override
										public void run() {
											CustomTab ct = new CustomTab(from);
											ct.getTA().appendText("[" + formater.format(new Date()) + "] : " + from
													+ " : " + message + "\n");
											tabpane.addCTab(ct);
										}
									});
									test = false;
								}

							}
						} else if (tampon.split(" ")[1].indexOf("353") >= 0) {
							c.traitementUtilisateurs(tampon);
							// actualisation de la liste des utilisateurs
							items = FXCollections.observableArrayList(c.utilisateurs);
							Platform.runLater(new Runnable() {
								@Override
								public void run() {
									listUtilisateurs.setItems(items);
								}
							});
						}

					} catch (IOException e) {

						e.printStackTrace();
					}
					if (tampon.indexOf("353") >= 0) {
						Platform.runLater(new Runnable() {
							@Override
							public void run() {
								stageLoading.hide();
							}
						});
					}

					// actualisation des utilisateurs
					if (tampon.split(" ")[1].indexOf("QUIT") >= 0 || tampon.split(" ")[1].indexOf("JOIN") >= 0) {
						System.out.println("raffraichissement de la liste utilisateurs");
						c.traitementUtilisateurs(tampon);
						items = FXCollections.observableArrayList(c.utilisateurs);
						Platform.runLater(new Runnable() {
							@Override
							public void run() {
								listUtilisateurs.setItems(items);
							}
						});

					}
				}

			}
		};
		ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
		executor.scheduleAtFixedRate(readingRunnable, 0, 10, TimeUnit.MILLISECONDS);
		// --------------------------ANIMATIONS-----------------------------------------------
		// animation bouton envoyer
		Translate translation = new Translate();
		btnSend.getTransforms().add(translation);
		Timeline timelineSend = new Timeline();
		timelineSend.getKeyFrames().addAll(new KeyFrame(Duration.ZERO, new KeyValue(translation.yProperty(), 0)),
				new KeyFrame(new Duration(50), new KeyValue(translation.yProperty(), -8)),
				new KeyFrame(new Duration(200), new KeyValue(translation.yProperty(), -10)),
				new KeyFrame(new Duration(300), new KeyValue(translation.yProperty(), -13)),
				new KeyFrame(new Duration(400), new KeyValue(translation.yProperty(), -10)),

				new KeyFrame(new Duration(425), new KeyValue(translation.yProperty(), -6)),
				new KeyFrame(new Duration(450), new KeyValue(translation.yProperty(), -0))

		);
		timelineSend.setCycleCount(Timeline.INDEFINITE);
		btnSend.setOnMouseEntered(actionEvent -> timelineSend.play());
		btnSend.setOnMouseExited(actionEvent -> {
			timelineSend.stop();
			translation.setY(0.0);
		});

		// animation bouton option
		Rotate rotation = new Rotate(0, 32, 31);
		btnOption.getTransforms().add(rotation);
		Timeline timelineOption = new Timeline();
		timelineOption.getKeyFrames().addAll(new KeyFrame(Duration.ZERO, new KeyValue(rotation.angleProperty(), 0)),
				new KeyFrame(new Duration(2000), new KeyValue(rotation.angleProperty(), 180)),
				new KeyFrame(new Duration(4000), new KeyValue(rotation.angleProperty(), 360)));
		timelineOption.setCycleCount(Timeline.INDEFINITE);
		btnOption.setOnMouseEntered(actionEvent -> timelineOption.play());
		btnOption.setOnMouseExited(actionEvent -> timelineOption.stop());

		// animation de la popup

		ScaleTransition st1 = new ScaleTransition(Duration.millis(250), rectanglePopup);
		st1.setByY(10);
		st1.setCycleCount(1);

		ScaleTransition st2 = new ScaleTransition(Duration.millis(500), rectanglePopup);
		st2.setByX(100);
		st2.setCycleCount(1);

		popup.setX(stageConnection.getX() + 6);
		popup.setY(stageConnection.getY() + 100);

		FadeTransition ft = new FadeTransition(Duration.millis(500), lblPopup);
		ft.setFromValue(0.0);
		ft.setToValue(1.0);

		popup.setOnShowing(actionEvent -> st1.play());
		st1.setOnFinished(actionEvent -> st2.play());
		st2.setOnFinished(actionEvent -> ft.play());
		popup.setOnHiding(actionEvent -> {
			rectanglePopup.setScaleX(1);
			rectanglePopup.setScaleY(1);
			lblPopup.setOpacity(0.0);
		});

	}

	// methode lecture et ecriture dans un fichier

	/**
	 * Ecrire dans un fichier
	 * 
	 * @param content La string a �crire dans le fichier en question
	 * @param file l'adresse du fichier dans lequel on �crit
	 */
	private void SaveFile(String content, File file) {
		try {
			FileWriter fileWriter;

			fileWriter = new FileWriter(file);
			fileWriter.write(content);
			fileWriter.close();
		} catch (IOException ex) {
			System.out.println(ex);
		}

	}

	/**
	 * Lire dans un Fichier
	 * 
	 * 
	 * @param file le ficher auquel on essaie d'acceder
	 * @return retourn le contenu du fichier
	 */
	private String readFile(File file) {
		StringBuilder stringBuffer = new StringBuilder();
		BufferedReader bufferedReader = null;
		try {
			bufferedReader = new BufferedReader(new FileReader(file));
			String text;
			while ((text = bufferedReader.readLine()) != null) {
				stringBuffer.append(text);
			}
		} catch (FileNotFoundException ex) {
			System.out.println(ex);
		} catch (IOException ex) {
			System.out.println(ex);
		} finally {
			try {
				bufferedReader.close();
			} catch (IOException ex) {
				System.out.println(ex);
			}
		}
		return stringBuffer.toString();
	}
}