package chat;

import java.util.ArrayList;

/**
 * Un tabPane am�liorer qui prends en charge mes onglets am�lior�s.
 * Classe n�c�ssaire a la gestion dynamique des messages priv�s via l'onglet
 * 
 * h�rite de TabPane 
 * 
 * @author Aygalic
 * @see CustomTab
 */

public class CustomTabPane extends javafx.scene.control.TabPane {
	
	/**
	 * ArrayList d'onglet amiliorer pour pouvoir y acceder via la methode getCTabByName 
	 * @see getCTabByName
	 */
	private ArrayList<CustomTab> tabList = new ArrayList<CustomTab>();

	/**
	 * contructeur de TabPane impl�ment�
	 */
	public CustomTabPane() {
		super();
	}

	/**
	 * Methode de recherche d'onglet par indice
	 * 
	 * @param i indince de l'onglet a retourner
	 * @return l'onglet de l'indice sp�cigfi� en parametre
	 */
	public CustomTab getCTabs(int i) {
		return this.tabList.get(i);
	}

	/**
	 * 
	 * @param CT onglet custom qu'on veux ajouteur a notre custom TAB et notre ArrayList
	 */
	public void addCTab(CustomTab CT) {
		this.getTabs().add(CT);
		this.tabList.add(CT);
	}

	/**
	 * Methode de recherche d'onglet par nom
	 * 
	 * @param s Le nom de l'onglet d�sir�
	 * @return L'onglet qui porte le nom pass� en parametre.
	 * @return null si aucun onglet ne porte ce nom
	 */
	public CustomTab getCTabByName(String s) {
		for (CustomTab ct : tabList) {
			if (ct.getText().equals(s))
				return ct;
		}
		return null;
	}

}
