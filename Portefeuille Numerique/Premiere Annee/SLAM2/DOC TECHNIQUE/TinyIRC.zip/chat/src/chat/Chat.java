package chat;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.ArrayList;

/**
 * Classe permettant de gerer la connexion au serveur
 * Contien la liste des utilisateurs
 * Envoi et lit les messages du serveur
 * System nerveux du chat, l'interface avec l'exterieur (le r�seau et l'utilisateur)
 * 
 * @author Aygalic
 *
 */

public class Chat {
	/**
	 * writer permet d'�crir au serveur
	 */
	BufferedWriter writer;
	/**
	 * reader permet de lire le serveur
	 */
	BufferedReader reader;
	/**
	 * le socket est l'interface de connexion sur laquelle s'appui reader et writer
	 */
	Socket socket;
	/**
	 * channel est le canal auquel nous nous connectons et auquel nos messages sont envoy�s
	 * nick est le pseudo nous lequel nos communiquon avec les autres utilisateurs
	 */
	String channel, nick;
	/**
	 * Liste dynamique contenant tout les nom des utilisateurs connect�s
	 */
	public ArrayList<String> utilisateurs = new ArrayList<String>();

	/**
	 * Constructeur d'objet Chat appel� par la methode createConnexion
	 * 
	 * @param serveur Adresse du serveur avec lequel la connection sera effectu�e
	 * @param port Port sur lequel la connection sera effectu�e
	 * @param channel	Channel sur lequel les messages seront envoy�s
	 * @param nick Pseudo sous lequel la communication avec les autre utilisateurs sera effectu�e
	 * @throws IOException
	 * 
	 */
	private Chat(String serveur, int port, String channel, String nick) throws IOException {
		this.socket = new Socket(serveur, port);
		this.socket.setSoTimeout(100000);
		this.writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
		this.reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		this.channel = channel;
		this.nick = nick;
	}
	
	/**
	 * Fait appel au contructeur pour se connecter au serveur
	 * Se connecte au Channel
	 * V�rifie que le pseudo n'est pas d�j� utilis�
	 * Si le pseudo est d�j� utilis�, la connexion n'est pas effectu�e
	 * 
	 * @param nick Pseudo utilis� pour la reception est l'envoie de message
	 * @param login	Login utilis� pour la connexion au servuer
	 * @param channel Channel de discution courant 
	 * @param serveur Serveur auquel le client se connecte 
	 * @param port Port via lequel la connexion est effectu�
	 * @return l'objet chat instanci�
	 * @return null si le nick est d�j� utilis�
	 * @throws IOException
	 */
	public static Chat createConnexion(String nick, String login, String channel, String serveur, int port)
				throws IOException {
		Chat c = new Chat(serveur, port, channel, nick);
		c.writer.write("Nick " + nick + "\r\n");
		c.writer.write("USER " + login + " 8 * : Java IRC hacks bot\r\n");
		c.writer.flush();
		String line = null;
		while ((line = c.reader.readLine()) != null) {
			if (line.indexOf("004") >= 0) {
				// loged in
				break;
			} else if (line.indexOf("443") >= 0) {
				System.out.println("Nickname already in use");
				return null;

			}
		}
		c.writer.write("JOIN " + channel + "\r\n");
		c.writer.flush();
		return c;
	}

	/**
	 * methode permettant l'envoi d'un message sur la channel courant
	 * 
	 * @param envoi Message a envoyer au serveur
	 * @throws IOException
	 */
	public void sendMessage(String envoi) throws IOException {
		getWriter().write("PRIVMSG " + this.channel + " :" + envoi + "\r\n");
		getWriter().flush();
	}
	/**
	 * Methode permettant l'envoi d'un message priv� � un utilisateur pr�cis
	 * 
	 * @param message Contenu du message
	 * @param utilisateur Destinataire
	 * @throws IOException
	 */
	public void sendPrivMessage(String message, String utilisateur) throws IOException {
		getWriter().write("PRIVMSG " + utilisateur + " :" + message + "\r\n");
		getWriter().flush();

	}

	
	/**
	 * Permet la lecture des r�ponse du serveur
	 * 
	 * Reponds automatiquement a la requette PING
	 * 
	 * 
	 * @return Les messages du serveur
	 * @throws IOException
	 */
	public String read() throws IOException {
		String line;
		while ((line = this.getReader().readLine()) != null) {
			if (line.toLowerCase().startsWith("PING ")) {
				this.getWriter().write("PONG " + line.substring(5) + "\r\n");
				this.getWriter().write("PRIVMSG " + this.channel + " : I got pinged! \r\n");
				this.getWriter().flush();
			}
			else{ 
				return line;
			}
		}
		return line;
	}


	// -----------------Gestion de la liste des utilisateurs -------------------
	/**
	 * Split la String pass� en parametre afin de d�t�cter si :
	 * - il s'agit du code 353 qui comprends la liste des utilisateur
	 * - il y a le mot cl� JOIN
	 * - il y a le mot cl� QUIT
	 * - fait appel au autre methodes li�es a la gestion des utilisateurs en cas de besoins
	 * 
	 * @param s message a analyser
	 */
	public void traitementUtilisateurs(String s) {
		if (s.split(" ")[1].indexOf("353") >= 0) {
			for (int i = 5; i < s.split(" ").length; i++) {
				this.addUltilisateur(s.split(" ")[i]);
				System.out.println("ajout d'utilisateur");
			}
		} else if (s.indexOf("JOIN") >= 0) {
			this.addUltilisateur(s.split(":")[1].split("!")[0]);
		} else if (s.indexOf("QUIT") >= 0) {
			this.delUtilisateur(s.split(":")[1].split("!")[0]);
		}
	}

	
	/**
	 * Ajoute un nom d'utilisateur a la liste d'utilisateur 
	 * @param u nom de l'utilisateur a ajouter
	 */
	public void addUltilisateur(String u) {
		if (!u.startsWith(":")) {
			utilisateurs.add(u);
		}
	}

	/**
	 * Supprime de la liste des utilisateurs le nom de l'utilisateur sp�cifi� 
	 * @param u Nom de l'utilisateur a supprimer
	 */
	public void delUtilisateur(String u) {
		utilisateurs.remove(utilisateurs.indexOf(u));
	}

	/**
	 * Permet de se d�connecter correctement du serveur
	 * @throws IOException
	 */
	public void exit() throws IOException {
		getWriter().write("/quit");
		getWriter().flush();
		this.socket.close();
	}


	/**
	 * 
	 * @return writer, le BufferedWriter le l'objet 
	 */
	public BufferedWriter getWriter() {
		return this.writer;
	}
	
	/**
	 * 
	 * @return reader, le BufferedReader le l'objet 
	 */
	public BufferedReader getReader() {
		return this.reader;
	}
}
