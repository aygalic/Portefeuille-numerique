package chat;

import javafx.scene.control.TextArea;
/**
 * Onglet am�lior� qui est li� a un TextArea qui lui est propre.
 * Cette classe permet d'acceder a un TextArea propre a un onglet, ce qui apporte une certaine flexibilit�
 * La gestion des messages priv�e est plus simple
 * L'interface utilisateur est simplifi�e de ce fait
 * 
 * @author Aygalic
 */
public class CustomTab extends javafx.scene.control.Tab {
	/**
	 * TextArea accessible grace a la methode getTA
	 */
	TextArea ta = new TextArea();
	//CustomTab CT; ne sert a rien

	/**
	 * Cr�e un onglet qui a pour titre la String pass� en parametre
	 * assossie a cette onglet un TextArea et d�fini ses propri�t� (non �ditable par d�faut)
	 * @param s Titre de l'onglet
	 */
	public CustomTab(String s) {
		super(s);
		this.ta = new TextArea();
		ta.setEditable(false);
		this.setContent(ta);
	}

	/**
	 * Getter qui donne l'acces au TextArea de cet onglet
	 * @return le TextArea de l'objet CustomTab
	 */
	public TextArea getTA() {
		return this.ta;
	}

}
