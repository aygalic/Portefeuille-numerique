<?php      
  header('Location: view/acceuil.php');      
?>