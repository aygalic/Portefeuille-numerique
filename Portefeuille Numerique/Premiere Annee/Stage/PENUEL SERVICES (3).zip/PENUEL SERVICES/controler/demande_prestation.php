<?php 
require_once('../view/head.php');
require_once('../model/model.php');
require_once('../view/prestation.php');
require_once('../view/footer.php');
